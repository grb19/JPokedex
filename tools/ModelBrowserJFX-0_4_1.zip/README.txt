
README - ModelBrowserJFX 0.4.1   
------------------------------

Complete the java-path in the batch file for your system(s) to run ModelBrowserJFX locally:

 - jimModelBrowserJFX-LIN-0_4_1.sh
 - jimModelBrowserJFX-OSX-0_4_1.sh
 - jimModelBrowserJFX-WIN-0_4_1.bat

To retrieve renderer information set the system property 'prism.verbose' to true: -Dprism.verbose=true (default: false).

AquaFX is supported on Mac OS X. Adjust the location of the correspoding archive (aquafx-0.1.jar) and set the application parameter 'aquafx' to true: aquafx=true (default: false). See http://aquafx-project.com/index.html for more information and download.  

The user guide provides short descriptions of all application features (Menu -> Help).

